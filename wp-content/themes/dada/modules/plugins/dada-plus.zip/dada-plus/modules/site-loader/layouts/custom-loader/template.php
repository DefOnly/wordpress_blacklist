<div class="pre-loader custom_loader">
    <div class="loader-inner">
        <span class="loader-image">
        <img class="pre_loader_image" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" src="<?php echo dada_customizer_settings('site_loader_image');?>"/>
        </span>
    </div>
</div>